
# JSONFORMS

## Installation

run `npm install` in a terminal in the same folder as index.html

## Running

Vite is used to run a development server for live reloading.  `https://vitejs.dev`

run `npm run dev` to start the development server

open a browser and go to `http://localhost:5173`

if using Chrome (or Brave) press F12 in the browser and in the top-right corner of devtools click on Toggle Device Toolbar which will show the page as though it's a mobile device.  The dimensions used for development were 360 x 640, which is the resolution of a Samsung Galaxy S5

## Creating a build

1. copy the `index.html` file, then rename it to jsonForms.html or something
2. create a `<style></style>` element in the `<head>` and copy in the css from `index.css`
3. replace `<script type="module" src="index.js"></script>` in the body with `<script></script>` and copy in the javascript from `index.js`
4. then double click on the html file in your file explorer to open it in a browser
